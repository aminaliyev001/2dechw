export const services = [
  {id:1, serviceName: "SERVICE 1", serviceDescription: "Description 1" },
  {id:2, serviceName: "SERVICE 2", serviceDescription: "Description 2" },
  {id:3, serviceName: "SERVICE 3", serviceDescription: "Description 3" },
  {id:4, serviceName: "SERVICE 4", serviceDescription: "Description 4" },
  {id:5, serviceName: "SERVICE 5", serviceDescription: "Description 5" },
  {id:6, serviceName: "SERVICE 6", serviceDescription: "Description 6" },
  {id:7, serviceName: "SERVICE 7", serviceDescription: "Description 7" },
  {id:8, serviceName: "SERVICE 8", serviceDescription: "Description 8" },
  {id:9, serviceName: "SERVICE 9", serviceDescription: "Description 9" },
  {id:10, serviceName: "SERVICE 10", serviceDescription: "Description 10" },
  {id:11, serviceName: "SERVICE 11", serviceDescription: "Description 11" },
  {id:12, serviceName: "SERVICE 12", serviceDescription: "Description 12" },
];

// document.getElementById('list').innerHTML = services.map((item) => {
//   return(
//     `<li>
//     <p>
//     ${item.serviceName}
//     </p>
//     <p>
//     ${item.serviceDescription}
//     </p>
//     </li>
//     `
//   )
// }).join('')