import { services } from "../../public/data/data"
import AddForm from "./AddForm"
import Services from "./Services/Services"
import { useState } from "react"
import Bag from  "./Bag"

function MainComp() {
  let [servicesArray, setServices] = useState(services)
  let [bagItems, setBagItems] = useState([]);

    return (
      <main>
        <AddForm servicesArray={servicesArray} setServices={setServices}/>
        <Services setServices={setServices} servicesArray={servicesArray} bagitems = {bagItems} setBagItems={setBagItems} />
        <Bag bagItems = {bagItems} setBagItems={setBagItems} />
      </main>
    )
  }
  
  export default MainComp
  
  