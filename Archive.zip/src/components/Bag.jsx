import BagItem from "./Services/BagItem";

function Bag({ bagItems, setBagItems }) {
    return (
        <div className="bag">
            {bagItems.length > 0 ? (
                bagItems.map((item,index) => (
                    <BagItem 
                        obj={item} 
                        key={index}
                        setBagItems={setBagItems} 
                        bagItems={bagItems} 
                    />
                ))
            ) : (
                <h2>Bag is empty</h2>
            )}
        </div>
    );
}
export default Bag;