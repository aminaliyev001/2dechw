function BagItem({obj,setBagItems,bagItems}) {
    function removeFromBag(id) {
        let newArr = [...bagItems];
        let elementIndex = newArr.findIndex((item) => item.id === id);
        newArr.splice(elementIndex, 1);
        setBagItems(newArr);
    }
    return (
    <li>
        <h3>{obj.serviceName}</h3>
        <p>{obj.serviceDescription}</p>
        <button onClick={() => removeFromBag(obj.id)}>Remove from Bag</button>
    </li>
    )
}
export default BagItem;