import EditForm from "./EditForm";
import { useState } from "react";

function ServicesItem({ obj, setServices, servicesArray,bagitems,setBagItems }) {
  let [flag, setFlag] = useState(false)


  function handleDelete(id) {
    let newArr = [...servicesArray];
    let elementIndex = newArr.findIndex((item) => item.id === id);
    newArr.splice(elementIndex, 1);
    setServices(newArr);
  }

  function addToBag(id) {
    let newArr = [...servicesArray];
    let elementSelected = newArr.find((item) => item.id === id);

    let newarr2 = [...bagitems];
    newarr2.push(elementSelected);
    setBagItems(newarr2);
  }

  return (
    <li>
      <h3>{obj.serviceName}</h3>
      <p>{obj.serviceDescription}</p>
      <button onClick={() => handleDelete(obj.id)}>DELETE</button>
      <button onClick={() => setFlag(!flag)}>EDIT</button>
      <button onClick={() => addToBag(obj.id)}>Add to bag</button>

      <EditForm flag={flag} id={obj.id} setServices={setServices} servicesArray={servicesArray}/>
    </li>
  );
}

export default ServicesItem;
