import ServicesItem from "./ServicesItem";


function Services({servicesArray,setServices,bagitems,setBagItems}) {

  
  return (
    <section className="services-list">
      <ul>
        
        {servicesArray.map((item, index) => (
          <ServicesItem
            key={index}
            obj={item}
            servicesArray={servicesArray}
            setServices={setServices}
            bagitems={bagitems}
            setBagItems={setBagItems}
          />
        ))}
      </ul>
    </section>
  );
}

export default Services;
